const express = require("express");
const path = require("path");

const app = express();
app.use(express.json());

// Servir arquivos estáticos da pasta atual
app.use(express.static(__dirname));

// Mock de login só para teste
app.post("/api/mock-login", (req, res) => {
  const { email } = req.body || {};
  if (email && email.includes("@")) {
    return res.json({
      ok: true,
      user: { name: "Einstein", email }
    });
  }
  res.status(400).json({ ok: false, error: "Email inválido" });
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
