document.getElementById("loginBtn").addEventListener("click", () => {
  alert("Login clicado ✔");
});

document.getElementById("langToggle").addEventListener("click", () => {
  alert("Trocar idioma ✔");
});
